module CPU_tb;
    reg clk;
    reg reset;
    reg PC_Enable;
    reg [8:0] RAM_Write_Data;
    reg [2:0] RAM_Write_Address;
    reg RAM_Write_Enable;
    reg [2:0] InD;
    reg InE;
    wire [2:0] OutD;
    wire [2:0] PC;
    wire [8:0] PI;
    wire [2:0] REG0, REG1, REG2, REG3;
    wire [8:0] RAM0, RAM1, RAM2, RAM3;
    wire [8:0] RAM4, RAM5, RAM6;

    CPU uut (
        .clk(clk), .reset(reset), .PC_Enable(PC_Enable), .PC(PC), .PI(PI),
        .RAM_Write_Data(RAM_Write_Data),
        .RAM_Write_Address(RAM_Write_Address),
        .RAM_Write_Enable(RAM_Write_Enable),
        .InD(InD), .InE(InE), .OutD(OutD),
        .REG0(REG0), .REG1(REG1), .REG2(REG2), .REG3(REG3),
        .RAM0(RAM0), .RAM1(RAM1), .RAM2(RAM2), .RAM3(RAM3),
        .RAM4(RAM4), .RAM5(RAM5), .RAM6(RAM6)
    );

    always 
    begin
        clk = ~clk; 
        #5;
    end 

    initial begin
        $dumpfile("test3.vcd");
        $dumpvars(0, CPU_tb);

        clk = 0;
        reset = 1;
        PC_Enable = 0;
        RAM_Write_Data = 0;
        RAM_Write_Address = 0;
        RAM_Write_Enable = 0;
        InD = 0;
        InE = 0;
        #10;



        reset = 0;
        #10
        InD = 3'b100;
        InE = 1'b1;
        PC_Enable = 0;
        RAM_Write_Enable = 1;

        RAM_Write_Address = 3'b000;   
        RAM_Write_Data = 9'b11_11_11_100;  // load [v] , r3
        #10;

        RAM_Write_Address = 3'b001;
        RAM_Write_Data = 9'b10_11_00_100;  // add ro, inr
        #10;

        RAM_Write_Address = 3'b010;   
        RAM_Write_Data = 9'b00_10_00_100;  // cmp
        #10;

        RAM_Write_Address = 3'b011;   
        RAM_Write_Data = 9'b01_11_00_001;  // jmp 
        #10;

        RAM_Write_Address = 3'b100;
        RAM_Write_Data = 9'b00_01_00_010;  // ADD OUTR, R0 ;OUTR = R3
        #10;

        RAM_Write_Address = 3'b101;
        RAM_Write_Data = 9'b10_11_11_000;  // ADD R1, 7 
        #10;



        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;
        RAM_Write_Enable = 0;
        PC_Enable = 1;
        #10;

        $finish;
    end

    initial begin
        $monitor("Time = %0t | clk = %b | reset = %b | PC_Enable = %b | PC = %b | PI = %b | RAM_E = %b | RAM_D = %b | RAM_A = %b | InE = %b | \n\t| InD = %b | OutD = %b | REG0 = %b | REG1 = %b | REG2 = %b | REG3 = %b | RAM0 = %b | RAM1 = %b |\n\t RAM2 = %b | RAM3 = %b | RAM4 = %b | RAM5 = %b | RAM6 = %b\n", 
                    $time, clk, reset, PC_Enable, PC, PI, RAM_Write_Enable, RAM_Write_Data, RAM_Write_Address, InE, InD, OutD, REG0, REG1, REG2, REG3, RAM0, RAM1, RAM2, RAM3, RAM4, RAM5, RAM6);
    end

endmodule
